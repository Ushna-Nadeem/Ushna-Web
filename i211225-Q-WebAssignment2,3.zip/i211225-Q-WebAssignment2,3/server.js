const express = require('express');
const mongoose = require('mongoose');
require('dotenv').config();
const cors = require('cors');
const userRoutes = require('./Route/userroute');
const postRoutes = require('./Route/blogpostroute');
const userInteractionRoutes = require('./Route/userinteractionroute');
const searchRoutes = require('./Route/searchroute');
const adminRoutes = require('./Route/adminroute');

const app = express();
app.use(express.json());
app.use(cors());

const mongodbUri = process.env.MONGODB_URI;
mongoose.connect(mongodbUri, { useNewUrlParser: true, useUnifiedTopology: true });

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');
});

app.use('/api/user', userRoutes);

app.use('/api/post', postRoutes);

app.use('/api/userinteraction', userInteractionRoutes);

app.use('/api/search', searchRoutes);

app.use('/api/admin', adminRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
