const User = require('../Model/usermodel');
const BlogPost = require('../Model/blogpostmodel');

const viewAllUsers = async (req, res) => {
  try {
    const users = await User.find();
    res.json({ users });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const blockUser = async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await User.findByIdAndUpdate(userId, { isBlocked: true }, { new: true });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ message: 'User blocked successfully', blockedUser: user });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const listAllBlogPosts = async (req, res) => {
  try {
    const blogPosts = await BlogPost.find()
      .populate('author', 'username')
      .select('title author createdAt');

    res.json({ blogPosts });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const viewBlogPost = async (req, res) => {
  try {
    const { postId } = req.params;
    const blogPost = await BlogPost.findById(postId)
      .populate('author', 'username')
      .select('title content author createdAt isDisabled');

    if (!blogPost) {
      return res.status(404).json({ error: 'Blog post not found' });
    }

    res.json({ blogPost });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const disableBlogPost = async (req, res) => {
  try {
    const { postId } = req.params;
    const blogPost = await BlogPost.findByIdAndUpdate(postId, { isDisabled: true }, { new: true });

    if (!blogPost) {
      return res.status(404).json({ error: 'Blog post not found' });
    }

    res.json({ message: 'Blog post disabled successfully', disabledBlogPost: blogPost });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

module.exports = { viewAllUsers, blockUser, listAllBlogPosts, viewBlogPost, disableBlogPost };
