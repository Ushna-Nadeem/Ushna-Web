const User = require('../Model/usermodel');
const Post = require('../Model/blogpostmodel');
const Notification = require('../Model/notificationmodel');

const followUser = async (req, res) => {
  try {
    const { userId } = req.params;
    const followerId = req.user._id; 

    const userToFollow = await User.findById(userId);

    if (!userToFollow) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (userToFollow.followers.includes(followerId)) {
      return res.status(400).json({ error: 'User is already being followed' });
    }

    userToFollow.followers.push(followerId);
    await userToFollow.save();

    const notification = new Notification({
      user: userToFollow._id,
      message: `${req.user.username} started following you.`,
    });
    
    await notification.save();

    res.json({ message: 'User followed successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

const getUserFeed = async (req, res) => {
    try {
      const user = await User.findOne({ username: req.user.username }).populate({
        path: 'posts',
        populate: {
          path: 'author comments.user',
          select: 'username email'
        },
      });
  
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
  
      const followedUsers = [...user.followers, user._id];
  
      const feed = await Post.find({ author: { $in: followedUsers } })
        .populate('author comments.user', 'username email')
        .sort({ createdAt: -1 });
  
      res.json({ feed });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };
  
  const getUserNotifications = async (req, res) => {
    try {
      const user = await User.findOne({ username: req.user.username }).populate('notifications');
  
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
  
      res.json({ notifications: user.notifications });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };  

module.exports = { followUser, getUserFeed, getUserNotifications };
