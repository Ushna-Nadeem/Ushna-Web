const Post = require('../Model/blogpostmodel');

const searchPosts = async (req, res) => {
  try {
    const { keywords, categories, authors, sortBy, sortOrder } = req.query;

    let query = {};

    if (keywords) {
      query.$or = [
        { title: { $regex: keywords, $options: 'i' } },
        { content: { $regex: keywords, $options: 'i' } },
      ];
    }

    if (categories) {
      query.categories = { $in: categories.split(',') };
    }

    if (authors) {
      query.author = { $in: authors.split(',') };
    }

    let posts = await Post.find(query);

    if (sortBy && sortOrder) {
      const sortOptions = {};
      sortOptions[sortBy] = sortOrder === 'asc' ? 1 : -1;
      posts = posts.sort(sortOptions);
    }

    res.json({ posts });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

module.exports = { searchPosts };
