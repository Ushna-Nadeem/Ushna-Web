const express = require('express');
const router = express.Router();
const postController = require('../Controller/blogpostcontroller');
const authenticateToken = require('../Middleware/authenticationmiddleware');

// Create a new post
router.post('/create', authenticateToken, postController.createPost);

// Get all posts with pagination and filtering options
router.get('/all', postController.getAllPosts);

// Get a specific post by ID
router.get('/:id', postController.getPostById);

// Update a post
router.put('/:id', authenticateToken, postController.updatePost);

// Delete a post
router.delete('/:id', authenticateToken, postController.deletePost);

// Rate a post
router.post('/:id/rate', authenticateToken, postController.ratePost);

// Comment on a post
router.post('/:id/comment', authenticateToken, postController.commentOnPost);

module.exports = router;
