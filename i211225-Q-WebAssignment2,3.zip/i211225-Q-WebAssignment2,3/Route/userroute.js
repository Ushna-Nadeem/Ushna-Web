const express = require('express');
const router = express.Router();
const { registerUser, loginUser, getUserProfile, updateUserProfile } = require('../Controller/usercontroller');
const authenticateToken = require('../Middleware/authenticationmiddleware');

// User Registration
router.post('/register', registerUser);

// User Login
router.post('/login', loginUser);

// User Profile Retrieval
router.get('/profile', authenticateToken, getUserProfile);

// User Profile Update
router.put('/profile', authenticateToken, updateUserProfile);

module.exports = router;
