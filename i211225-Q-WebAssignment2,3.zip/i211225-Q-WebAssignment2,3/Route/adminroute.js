const express = require('express');
const router = express.Router();
const adminController = require('../Controller/admincontroller');
const authenticateToken = require('../Middleware/authenticationmiddleware');

// Ensure only admin has access to these routes
router.use(authenticateToken, (req, res, next) => {
  if (req.user.role === 'admin') {
    next();
  } else {
    res.status(403).json({ error: 'Forbidden. Only admin can access these routes.' });
  }
});

router.get('/users', adminController.viewAllUsers);
router.put('/block/user/:userId', adminController.blockUser);
router.get('/blogposts', adminController.listAllBlogPosts);
router.get('/blogpost/:postId', adminController.viewBlogPost);
router.put('/disable/blogpost/:postId', adminController.disableBlogPost);

module.exports = router;
