const express = require('express');
const router = express.Router();
const userInteractionController = require('../Controller/userinteractioncontroller');
const authenticateToken = require('../Middleware/authenticationmiddleware');

router.post('/follow/:userId', authenticateToken, userInteractionController.followUser);
router.get('/feed', authenticateToken, userInteractionController.getUserFeed);
router.get('/notifications', authenticateToken, userInteractionController.getUserNotifications);

module.exports = router;
